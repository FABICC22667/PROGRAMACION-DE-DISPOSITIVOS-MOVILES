import 'package:laboratorio_taller/screens/home_screen.dart';
import 'package:flutter/material.dart';
//import 'home_screen.dart'; // Asegúrate de que la importación sea correcta según la ubicación de tu archivo

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Portal de Ingeniería de Sistemas',
      theme: ThemeData(
        primarySwatch: Colors.green, // Puedes ajustar el tema según tus preferencias
      ),
      home: HomeScreem(), // Aquí estableces tu HomeScreen como pantalla inicial
      debugShowCheckedModeBanner: false, // Opcional: quita el banner de debug
    );
  }
}