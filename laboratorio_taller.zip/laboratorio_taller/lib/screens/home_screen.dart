import 'package:flutter/material.dart';

class HomeScreem extends StatelessWidget {
  final options = [
    'Noticias y Actualidad',
    'Biblioteca Central',
    'Informaciones',
    'Pensum',
    'Repositorios',
    'Foros',
  ];
  final List<String> imageList = [
    'assets/images/biblioteca.jpeg',
    'assets/images/foros.jpeg',
    'assets/images/home.jpeg',
    'assets/images/informacion.jpeg',
    'assets/images/noticias.jpeg',
    'assets/images/pensum.jpeg',
    'assets/images/screens.jpeg.jpeg',
    'assets/images/repositorios.jpeg',
  ];
  HomeScreem({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Portal Ingenieria de Sistemas"),
        backgroundColor: Colors.greenAccent,
        leading: Icon(Icons.airline_stops_outlined),
      ),
      body: Column(
        children: [
          SizedBox(
            height: 200,
            child: PageView.builder(
              itemCount: imageList.length,
              itemBuilder: (context, index) {
                return Image.asset(imageList[index], fit: BoxFit.cover);
              },
            ),
          ),
          Expanded(
            child: ListView.separated(
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(options[index]),
                  leading: Icon(Icons.book),
                  trailing: Icon(Icons.arrow_forward_ios),
                  onTap: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('Seleccionaste: ${options[index]}'),
                        duration: Duration(seconds: 2),
                      ),
                    );
                  },
                );
              },
              separatorBuilder: (context, index) => Divider(),
              itemCount: options.length,
            ),
          ),
        ],
      ),
    );
  }
}
